package com.company;

import jdk.internal.org.objectweb.asm.tree.analysis.Value;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.LinkedList;
import java.util.Queue;

public class Pesan_Tiket_BIS {
    private JPanel panel1;
    private JComboBox cbTujuan;
    private JComboBox cbJumlah;
    private JComboBox cbTanggal;
    private JComboBox cbBulan;
    private JTextField tfHarga;
    private JTextField tfNama1;
    private JTextField tfNama2;
    private JTextField tfNama3;
    private JTextField tfNama4;
    private JButton BATALButton;
    private JTextArea taInfo;
    private JTextArea taTiket;
    private JTextField tfJam;
    private JButton PESANButton;
    private JButton RESETButton;
    private JLabel jlNP4;
    private JLabel jlNP3;
    private JLabel jlNP2;
    private JLabel jlNP1;

    public Pesan_Tiket_BIS() {
        taInfo.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
                taInfo.setText("PERHATIAN !" +
                        "\n1. Anda Hanya Bisa Mengisikan Nama Sesuai Dengan Jumlah Penumpang" +
                        "\n2. Pastikan Anda Telah Memasukan Seluruh Nama Penumpang");
            }
        });
        cbTujuan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tujuan = cbTujuan.getSelectedItem().toString();
                Integer jumlah= Integer.parseInt(cbJumlah.getSelectedItem().toString());
                String tanggal = cbTanggal.getSelectedItem().toString();
                Integer harga = 0;
                String jam = "";

                if(tujuan=="JOGJA-BEKASI"){
                    harga=150000;
                    jam = "16.30 WIB";
                }else if (tujuan =="JOGJA-JAKARTA") {
                    harga = 180000;
                    jam= "15.30 WIB";
                }else if (tujuan == "JOGJA-TANGERANG"){
                    harga=190000;
                    jam = "15.00 WIB";
                }else if (tujuan =="JOGJA-PARUNG"){
                    harga=190000;
                    jam = "15.30 WIB";
                }else if (tujuan == "JOGJA-MERAK"){
                    harga=245000;
                    jam = "13.00 WIB";
                }

                Integer tharga = harga*jumlah;
                tfHarga.setText(String.valueOf(tharga));
                tfJam.setText(jam);

            }
        });
        cbJumlah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tujuan = cbTujuan.getSelectedItem().toString();
                Integer jumlah= Integer.parseInt(cbJumlah.getSelectedItem().toString());
                String tanggal = cbTanggal.getSelectedItem().toString();
                Integer harga = 0;


                if(tujuan=="JOGJA-BEKASI"){
                    harga=150000;
                }else if (tujuan =="JOGJA-JAKARTA") {
                    harga = 180000;
                }else if (tujuan == "JOGJA-TANGERANG"){
                    harga=190000;
                }else if (tujuan =="JOGJA-PARUNG"){
                    harga=190000;
                }else if (tujuan == "JOGJA-MERAK"){
                    harga=245000;
                }

                Integer tharga = harga*jumlah;
                tfHarga.setText(String.valueOf(tharga));

                if(jumlah==1){
                    tfNama1.setEnabled(true);
                    tfNama2.setEnabled(false);
                    tfNama3.setEnabled(false);
                    tfNama4.setEnabled(false);
                    jlNP1.setEnabled(true);
                    jlNP2.setEnabled(false);
                    jlNP3.setEnabled(false);
                    jlNP4.setEnabled(false);
                }else if(jumlah==2){
                    tfNama1.setEnabled(true);
                    tfNama2.setEnabled(true);
                    tfNama3.setEnabled(false);
                    tfNama4.setEnabled(false);
                    jlNP1.setEnabled(true);
                    jlNP2.setEnabled(true);
                    jlNP3.setEnabled(false);
                    jlNP4.setEnabled(false);
                }else if (jumlah==3) {
                    tfNama1.setEnabled(true);
                    tfNama2.setEnabled(true);
                    tfNama3.setEnabled(true);
                    tfNama4.setEnabled(false);
                    jlNP1.setEnabled(true);
                    jlNP2.setEnabled(true);
                    jlNP3.setEnabled(true);
                    jlNP4.setEnabled(false);
                }else if (jumlah==4) {
                    tfNama1.setEnabled(true);
                    tfNama2.setEnabled(true);
                    tfNama3.setEnabled(true);
                    tfNama4.setEnabled(true);
                    jlNP1.setEnabled(true);
                    jlNP2.setEnabled(true);
                    jlNP3.setEnabled(true);
                    jlNP4.setEnabled(true);
                }

            }
        });

        PESANButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tujuan = cbTujuan.getSelectedItem().toString();
                Integer jumlah= Integer.parseInt(cbJumlah.getSelectedItem().toString());
                String tanggal = cbTanggal.getSelectedItem().toString();
                String bulan = cbBulan.getSelectedItem().toString();
                Integer harga = 0;
                String jam = "00.00";
                boolean cek0 = false;
                boolean cek1 = false;
                boolean cek2 = false;
                boolean cek3 = true;
                boolean cek4 = true;
                boolean [] cek = new boolean[jumlah];

                Queue<String> nama_Penumpang = new LinkedList<>();
                nama_Penumpang.add(tfNama1.getText());
                nama_Penumpang.add(tfNama2.getText());
                nama_Penumpang.add(tfNama3.getText());
                nama_Penumpang.add(tfNama4.getText());


                String nama[] = new String[jumlah];
                for(int i=0; i<jumlah; i++){
                    nama[i]=nama_Penumpang.remove();
                }

                if(tujuan=="JOGJA-BEKASI"){
                    harga=150000;
                    jam = "16.30 WIB";
                }else if (tujuan =="JOGJA-JAKARTA") {
                    harga = 180000;
                    jam= "15.30 WIB";
                }else if (tujuan == "JOGJA-TANGERANG"){
                    harga=190000;
                    jam = "15.00 WIB";
                }else if (tujuan =="JOGJA-PARUNG"){
                    harga=190000;
                    jam = "15.30 WIB";
                }else if (tujuan == "JOGJA-MERAK"){
                    harga=245000;
                    jam = "13.00 WIB";
                }
                if(tfNama1.getText().matches(".*[^a-z&&[^A-Z&&[\\S]]].*") || tfNama2.getText().matches(".*[^a-z&&[^A-Z&&[\\S]]].*") || tfNama3.getText().matches(".*[^a-z&&[^A-Z&&[\\S]]].*") || tfNama4.getText().matches(".*[^a-z&&[^A-Z&&[\\S]]].*")) {
                    cek0=false;
                    JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH MEMUAT ANGKA ATAU SIMBOL", "PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                }else {
                    cek0=true;

                }
                if (tujuan=="-PILIH-") {
                    JOptionPane.showMessageDialog(panel1, "ANDA BELUM MEMILIH TUJUAN", "PERINGATAN !", JOptionPane.INFORMATION_MESSAGE);
                    cek1=false;
                }else {
                    cek1=true;
                }
                if (tanggal == "-PILIH-" || bulan =="-BULAN-") {
                    JOptionPane.showMessageDialog(panel1, "ANDA BELUM MEMILIH TANGGAL", "PERINGATAN !", JOptionPane.INFORMATION_MESSAGE);
                    cek2=false;
                } else {
                    cek2=true;
                }
                switch (jumlah){
                    case 1 : if(nama[0].isEmpty()){
                        cek3=false;
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH KOSONG", "PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                    }
                    break;
                    case 2 : if(nama[0].isEmpty() || nama[1].isEmpty()){
                        cek3=false;
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH KOSONG", "PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                    }
                    break;
                    case 3 : if(nama[0].isEmpty() || nama[1].isEmpty() || nama[2].isEmpty()){
                        cek3=false;
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH KOSONG", "PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                    }
                        break;
                    case 4 : if(nama[0].isEmpty() || nama[1].isEmpty() || nama[2].isEmpty() || nama[3].isEmpty()){
                        cek3=false;
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH KOSONG", "PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                    }
                        break;
                    default:
                }
                switch (jumlah){
                    case 1 : if (tfNama1.getText().matches("^[\\s].*") || tfNama1.getText().matches(".*[\\s]$")){
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH DIAWALI ATAU DIAKHIRI SPASI","PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                        cek4=false;
                    }
                    break;
                    case 2 : if (tfNama1.getText().matches("^[\\s].*") || tfNama1.getText().matches(".*[\\s]$") || tfNama2.getText().matches("^[\\s].*") || tfNama2.getText().matches(".*[\\s]$")){
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH DIAWALI ATAU DIAKHIRI SPASI","PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                        cek4=false;
                    }
                    break;
                    case 3 : if (tfNama1.getText().matches("^[\\s].*") || tfNama1.getText().matches(".*[\\s]$") || tfNama2.getText().matches("^[\\s].*") || tfNama2.getText().matches(".*[\\s]$") || tfNama3.getText().matches("^[\\s].*") || tfNama3.getText().matches(".*[\\s]$") ){
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH DIAWALI ATAU DIAKHIRI SPASI","PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                        cek4=false;
                    }
                    break;
                    case 4 : if (tfNama1.getText().matches("^[\\s].*") || tfNama1.getText().matches(".*[\\s]$") || tfNama2.getText().matches("^[\\s].*") || tfNama2.getText().matches(".*[\\s]$") || tfNama3.getText().matches("^[\\s].*") || tfNama3.getText().matches(".*[\\s]$") || tfNama4.getText().matches("^[\\s].*") || tfNama4.getText().matches(".*[\\s]$") ){
                        JOptionPane.showMessageDialog(panel1, "NAMA TIDAK BOLEH DIAWALI ATAU DIAKHIRI SPASI","PERHATIAN !", JOptionPane.INFORMATION_MESSAGE);
                        cek4=false;
                    }
                    break;
                    default:
                }




                if(cek0==true && cek1==true && cek2==true && cek3==true &&cek4 ==true){
                    for (int b=0; b<jumlah; b++){
                        taTiket.append("TIKET PENUMPANG\n\n" +
                                "Nama" + "\t: " + nama[b].toUpperCase() + "\n" +
                                "Tujuan" + "\t: " + tujuan + "\n" +
                                "Tanggal\t: " + tanggal + " " + bulan + "\n" +
                                "Jam\t: " + jam + "\n" +
                                "Harga" + "\t: Rp." + harga + "\n\n\n"
                        );
                    }
                }


                if(cek0==true && cek1==true && cek2==true && cek3==true && cek4==true) {
                    cbTujuan.setEnabled(false);
                    cbJumlah.setEnabled(false);
                    cbTanggal.setEnabled(false);
                    cbBulan.setEnabled(false);
                    tfJam.setEnabled(false);
                    tfHarga.setEnabled(false);
                    tfNama1.setEnabled(false);
                    tfNama2.setEnabled(false);
                    tfNama3.setEnabled(false);
                    tfNama4.setEnabled(false);
                    BATALButton.setEnabled(false);
                    PESANButton.setEnabled(false);
                    jlNP1.setEnabled(false);
                    jlNP2.setEnabled(false);
                    jlNP3.setEnabled(false);
                    jlNP4.setEnabled(false);
                    RESETButton.setEnabled(true);
                }



            }
        });

        cbBulan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int t =1;
                if(cbBulan.getSelectedItem().toString() == "JUNI") {
                    cbTanggal.removeAllItems();
                    for (t=1; t<31; t++){
                        cbTanggal.addItem(t);
                    }
                }else {
                    if (cbBulan.getSelectedItem().toString() != "-BULAN-") {
                        cbTanggal.removeAllItems();
                        while (t <= 31) {
                            cbTanggal.addItem(t);
                            t++;
                        }
                    }
                }

                if(cbBulan.getSelectedItem().toString()=="-BULAN-"){
                    cbTanggal.removeAllItems();
                    cbTanggal.addItem("-HARI-");
                }
            }
        });

        BATALButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfNama1.setText("");
                tfNama2.setText("");
                tfNama2.setEditable(false);
                tfNama3.setText("");
                tfNama3.setEditable(false);
                tfNama4.setText("");
                tfNama4.setEditable(false);
                tfHarga.setText("");
                cbJumlah.setSelectedItem("1");
                cbTujuan.setSelectedItem("-PILIH-");
                cbTanggal.setSelectedItem("-HARI-");
                cbBulan.setSelectedItem("-BULAN-");
                jlNP1.setEnabled(true);
                jlNP2.setEnabled(false);
                jlNP3.setEnabled(false);
                jlNP4.setEnabled(false);
                RESETButton.setEnabled(false);

            }
        });

        RESETButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cbTujuan.setSelectedItem("-PILIH-");
                cbTujuan.setEnabled(true);
                cbJumlah.setSelectedItem("1");
                cbJumlah.setEnabled(true);
                cbTanggal.setSelectedItem("-HARI-");
                cbTanggal.setEnabled(true);
                cbBulan.setSelectedItem("-BULAN-");
                cbBulan.setEnabled(true);
                tfJam.setText("");
                tfJam.setEnabled(true);
                tfHarga.setText("");
                tfHarga.setEnabled(true);
                tfNama1.setText("");
                tfNama1.setEnabled(true);
                tfNama2.setText("");
                tfNama2.setEnabled(false);
                tfNama3.setText("");
                tfNama3.setEnabled(false);
                tfNama4.setText("");
                tfNama4.setEnabled(false);
                taTiket.setText("");
                BATALButton.setEnabled(true);
                PESANButton.setEnabled(true);
                jlNP1.setEnabled(true);
                jlNP2.setEnabled(false);
                jlNP3.setEnabled(false);
                jlNP4.setEnabled(false);
                RESETButton.setEnabled(false);
            }
        });

    }


    public static void main(String[] args) {
        JFrame frame = new JFrame("Pesan Tiket BIS");
        frame.setContentPane(new Pesan_Tiket_BIS().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
